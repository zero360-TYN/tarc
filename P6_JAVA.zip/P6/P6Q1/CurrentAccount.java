public class CurrentAccount extends Account {
    private static int freeTransactions = 3;
    private static double transactionFee = 2.00;
    private int transactionCount;

    public CurrentAccount(String accNumber,double balance){
        super(accNumber,balance);
        transactionCount = 0;
    }

    public static int getFreeTransactions(){
        return freeTransactions;
    }
    public static double getTransactionsFee(){
        return transactionFee;
    }
    public int getTransactionCount(){
        return transactionCount;
    }
    public void incrementTransactionCount(){
        transactionCount++;
    }
    public void doubleTransactionFee(){
        super.withdraw(transactionFee);
    }

    public void deductTransactionFee() {
        super.withdraw(transactionFee);
    }

    public boolean withdraw(double amount){
        boolean successful = super.withdraw( amount);
        if(successful){
            transactionCount++;
            if(transactionCount >freeTransactions){
                deductTransactionFee();
            }
        }
        return successful;
    }

    public void deposit(double amount){
        super.deposit(amount);
        transactionCount++;
        if(transactionCount > freeTransactions){
            deductTransactionFee();
        }
    }

    public String toString(){
        return super.toString() + "\n Transaction Count: " + transactionCount;
    }

}