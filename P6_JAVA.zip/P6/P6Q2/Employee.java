package P6Q2;

public class Employee {
    
    private String name;
    private int yearjoined;
    private double basicSalary;

    public Employee(String name,int yearJoin,double basicSalary){
        this.name = name;
        this.yearjoined = yearJoin;
        this.basicSalary = basicSalary;  
    }

    //getter
    public String getname(){
        return this.name;
    }
    public int getyearjoined(){
        return this.yearjoined;
    }
    public double getBasicSalary(){
        return this.basicSalary;
    }
    //setter
    public void setname(String name){
        this.name = name;
    }
    public void setyearjoined(int year){
        this.yearjoined = year;
    }
    public void setBascicSalary(double salary){
        this.basicSalary =salary;
    }

    public String toString(){
        return String.format("Name:%s\nYearjoined:%d\nBasicSalary:%.2f",this.name,this.yearjoined,this.basicSalary);
    }
}
