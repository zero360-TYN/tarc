import java.util.Scanner;
public class P5Q2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String str = input.nextLine();

        String newStr = str.toUpperCase();

        char[] vowels ={'A','E','I','O','U'};

        for (char vowel :vowels){
            newStr = newStr.replace(vowel, 'x');

        }

        System.out.printf("UpperCase: %s",newStr);
    }
}
