import java.util.Date;

public class Account {
    private String accNumber;
    private double balance;
    private Date dateCreated;

    public Account() {
        dateCreated = new Date();
    }

    public Account(String accNumber, double balance) {
        this.accNumber = accNumber;
        this.balance = balance;
        dateCreated = new Date();
    }

    public String getAccNumber() {
        return accNumber;
    }

    public double getBalance() {
        return balance;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public boolean withdraw(double amount) {
        if(amount > balance) {
            return false;
        } else {
            balance -= amount;
            return true;
        }

    }
    public String toString(){
        return String.format("Account Number: %s \nbalance: RM%.2f\nDate Created: %s",
                            accNumber,balance,dateCreated);
    }

    public boolean equals(Object o){
        Account othAcc = (Account) o;
        if(this.accNumber == othAcc.accNumber){
            return true;
        }else{
            return false;
        }
    }
}