﻿namespace Demo;

public static class Extensions
{
    public static bool isAjax(this HttpRequest request)
    {
        return request.Headers.XRequestedWith == "XMLHttpRequest"; 
    }
}
