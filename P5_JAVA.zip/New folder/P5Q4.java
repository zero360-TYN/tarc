import java.util.Scanner;
public class P5Q4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean invalid = false;

        System.out.print("Enter a product code: ");
        String productCode = input.next();

        if(productCode.length() != 8){
            invalid = true;
        }

        for(int i = 0; i< productCode.length();i++){
            char ch = productCode.charAt(i);

            if(!Character.isLetter(ch) && !Character.isDigit(ch)){
                invalid = true;
                break;
            }
            else if(i<2){
                if(Character.isLetter(ch) == false || Character.isUpperCase(ch)){
                    
                }
            }
        }
    }
}
