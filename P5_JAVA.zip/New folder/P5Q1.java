import java.util.Scanner;
public class P5Q1{
    private final static String VOWELS = "aeiou";

    public static int[] countVowels(String str){

        int[] occurence = {0,0,0,0,0};
        if(str == null || str.isEmpty()){
            return occurence;
        }
        char[] charArr = str.toCharArray();

        for(char ch:charArr){
            int indexFound = VOWELS.indexOf(Character.toLowerCase(ch));
            if(indexFound != -1){
                occurence[indexFound]++;
            }
        }
        return occurence;
    }

    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a word");
        String word = input.next();

        System.out.println("The Word" + word + "Contains: ");
        int[] occurence = countVowels(word);

        for(int i = 0; i<VOWELS.length(); i++){
            System.out.println(VOWELS.charAt(i) + ": " +occurence[i]);
        }
    }
}