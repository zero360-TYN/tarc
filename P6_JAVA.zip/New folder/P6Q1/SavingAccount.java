package P6Q1;

public class SavingAccount extends Account {
    private static double interestRate = 0.05;

    public SavingAccount(){

    }
    public SavingAccount(String accNumber,double balance){
        super(accNumber,balance);
        
    }

    public static double getInterwatRate(){
        return interestRate;
    }

    public static void setInterestRate(double interestRate){
        SavingAccount.interestRate = interestRate;
    }

    public double calcInterest(){
        return getbalance() * interestRate/12;
    }

    public void addInterest(){
        double interest = calcInterest();
        deposit(interest);
    }
}
