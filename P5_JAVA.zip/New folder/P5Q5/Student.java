package P5Q5;
public class Student {
    //data field
    private String studentID;
    private String name;
    private String school;

    //conststucter
    public Student(String stuID, String name, String school){
        this.studentID = stuID;
        this.name = name;
        this.school = school;
    }

    //Accessor
    public String getStudentId(){
        return this.studentID;
    }
    public String getName(){
        return this.name;
    }
    public String getSchool(){
        return this.school;
    }
    //Mutator
    public void setStudentId(String Stuid){
        this.studentID = Stuid;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setSchool(String school){
        this.school = school;
    }

    public static boolean validateStudentID(Student student){
        String stuID = student.studentID;

        char schoolcode = Character.toUpperCase(stuID.charAt(0));
        String regNo = student.studentID.substring(1,student.studentID.length());

        if(!Character.isLetter(schoolcode) || regNo.length() != 5){
            return false;
        }
        else{
            for(int i = 0; i< regNo.length();i++){
                if(!Character.isDigit(regNo.charAt(i))){
                    return false;
                }
            }
        }

        boolean valid = true;
        switch (schoolcode) {
            case 'A':
                //FASC
                valid = student.school.equals("FASC");
                break;
            case 'B':
                valid = student.school.equals("FAFB");
        }
        return valid; 
    }

}
