import java.util.Scanner;

public class TesCurrentAccount {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        CurrentAccount c = new CurrentAccount("12345", 10000.00);

        int selection = 4;
        do {
            System.out.println("\n1. Widthdrawal");
            System.out.println("2. Deposit");
            System.out.println("3. Check Balance");
            System.out.println("4. Quit");
            System.out.print("Enter choice:");
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    System.out.println("\nWITHDRAWAL");
                    System.out.println("-".repeat(50));
                    System.out.printf("Current balance:RM%.2f",c.getBalance());
                    System.out.print("\nEnter Amount: RM");
                    double amount = input.nextDouble();
                    if(c.withdraw(amount)){
                        if(c.getTransactionCount() > CurrentAccount.getFreeTransactions()){
                            c.doubleTransactionFee();
                        }
                        System.out.printf("Updated balance: RM%.2f",c.getBalance());
                    }else{
                        System.out.println("Transaction failed: Insufficient Balance");
                    }
                    break;
                case 2:
                    System.out.println("\nDEPOSIT");
                    System.out.println("-".repeat(50));
                    System.out.printf("Current balance:RM%.2f",c.getBalance());
                    System.out.print("\nEnter Amount: RM");
                    amount = input.nextDouble();
                    c.deposit(amount);
                    c.incrementTransactionCount();
                    if(c.getTransactionCount() > CurrentAccount.getFreeTransactions()){
                        c.deductTransactionFee();
                    }
                    System.out.printf("Updated balance: RM%.2f",c.getBalance());
                    break;
                case 3:
                    System.out.printf("Updated balance: RM%.2f",c.getBalance());
                    break;
                case 4:
                    System.out.println("\n\nTerminating program...");
            }
        }while(selection >=1 && selection <= 3);
    }
    
}
