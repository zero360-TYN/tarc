package P5Q5;

public class Test_Student {
    public static void main(String[] args) {
        Student stu1 = new Student("A12345", "Yuik Hao", "FASC");
        System.out.println(Student.validateStudentID(stu1));
        System.out.println(stu1.getName()+" is studying in " + stu1.getSchool());

    }

}
