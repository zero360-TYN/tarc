

public class TestAccount {
    public static void main(String[] args) {
        SavingsAccount acc1 = new SavingsAccount("12345",2000.00);
        CurrentAccount acc2 = new CurrentAccount("12345",1000.00);
        //test1
        System.out.printf("Saving account %s has balance:RM%.2f\n",acc1.getAccNumber(),acc1.getBalance());
        System.out.println("-".repeat(50));
        System.out.println("Transaciton Deposit RM100.00");
        acc1.deposit(100.00);
        System.out.printf("Updated balance:RM%.2f\n",acc1.getBalance());

        //test 2
        System.out.println("\nTransaction: withdraw RM5000.00");
        boolean successful = acc1.withdraw(5000.00);
        if (!successful){
            System.out.println("Transaction failed. Withdrawal amount > balance");
        }
        else{
            System.out.printf("Updated balance: RM%.2f\n",acc1.getBalance());
        }
        System.out.println("\nTransaction: withdraw RM5000.00");
        //test 3
        successful = acc1.withdraw(500.00);
        if (!successful){
            System.out.println("Transaction failed. Withdrawal amount > balance");
        }
        else{
            System.out.printf("Updated balance: RM%.2f\n",acc1.getBalance());
        }
    }
}
